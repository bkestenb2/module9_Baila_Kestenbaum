# logger.py
import os
"""
FruitProj: logger module

Goal:
    Append the chosen filename to docs/log.txt.
    Each line in log.txt is one record (one choice).

Pseudocode:
    FUNCTION log_choice(filename, log_filename):
        SET log_path TO join DOCS_DIR and log_filename
        TRY:
            OPEN log_path in append mode
                WRITE filename + newline
        EXCEPT FileNotFoundError:
            PRINT friendly error about missing docs folder
"""




DOCS_DIR = "docs"

def log_choice(filename, log_filename="log.txt", write_mode = 'w'):
    log_path = os.path.join(DOCS_DIR, log_filename)

    try:
        with open(log_path, "a") as f:
            f.write(filename + "\n")
    except FileNotFoundError as ff:
        print(ff)

def re_write_log(fruit_lst, log_filename = "log.txt"):
    pass


if __name__ == "__main__":
    pass