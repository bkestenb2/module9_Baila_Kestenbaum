# image_list.py
import os
"""
FruitProj: image_list module

Goal:
    Read docs/images.txt, process each line as a record, and return
    a list of full image paths like 'imgs/apple.jpg'.

Pseudocode:
    FUNCTION load_image_list(doc_filename):
        SET images TO empty list
        SET full_path TO join DOCS_DIR and doc_filename
        TRY:
            OPEN full_path for reading
                FOR each line in file:
                    STRIP newline/whitespace from line
                    IF line is not empty:
                        SET img_path TO join IMG_DIR and line
                        APPEND img_path to images
        EXCEPT FileNotFoundError:
            PRINT friendly error
            RETURN empty list
        RETURN images
"""

import os

DOCS_DIR = "docs"
IMG_DIR = "imgs"


def load_image_list(doc_filename="images.txt"):
    """
    Load image file names from docs/images.txt and return a list of full paths.

    See module docstring for full pseudocode.
    """
    # TODO: initialize an empty list called images
    # images = ...
    images = []
    full_path = os.path.join(DOCS_DIR, doc_filename)
    try:
        with open(full_path, "r") as f:
            for line in f:
                    line = line.strip()
                    if line != "":
                        images.append(os.path.join(IMG_DIR, line))
    except FileNotFoundError as ff:
        print(ff)
        return []

    return images

if __name__ == "__main__":
    images = load_image_list()
    print("TEST image_list:", images)
