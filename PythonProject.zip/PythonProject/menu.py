# menu.py
"""
FruitProj: menu module

Goal:
    Build a numbered menu from a list of image paths and ask the user
    to choose one by number.

Pseudocode:
    FUNCTION menu_str(images):
        CREATE empty list lines
        ADD title line to lines
        FOR each index, filename in images (starting at 1):
            EXTRACT base filename (no folder, no .jpg)
            ADD "index. name" line to lines
        ADD "0. Quit" line
        JOIN lines with newlines + "> " and RETURN

    FUNCTION grab_fruit_choice(images):
        LOOP forever:
            DISPLAY menu_str(images) and get input
            TRY to convert input to integer choice
                IF choice == 0: RETURN None
                ELSE IF 1 <= choice <= number of images:
                    RETURN choice - 1 (0-based index)
                ELSE: print "out of range"
            EXCEPT ValueError: print "please enter a number"
"""

import os


def menu_str(images):
    """
    Build and return the menu string shown to the user.

    See module docstring for full pseudocode.
    """
    lines = "WHich file should I load? Select a number. \n"
    for index, fruit in enumerate(images, start=1):
        name = os.path.basename(fruit).replace(".jpg", "")
        lines += str(index) + ". " + name + "\n"
    lines += "0. Quit \n"
    return lines


def print_user_menu(img_list):
    """
    print user friendly list
    :param img_list:
    :return:
    """
    pass


def grab_fruit_choice(images):
    """
    Repeatedly show the menu and return a valid index (0-based)
    or None if the user chooses to quit.
    """
    while True:
        try:
            choice = int(input(menu_str(images)))
            if choice == 0:
                return None
            elif 1<= choice <= len(images):
                return choice - 1
            else:
                print("Please give me a number")
        except ValueError as v:
            print("Please enter a whole number", v)



if __name__ == "__main__":
    test_imgs = ["imgs/apple.jpg", "imgs/lemon.jpg", "imgs/tomato.jpg"]
    idx = grab_fruit_choice(test_imgs)
    print("You picked index:", idx)
