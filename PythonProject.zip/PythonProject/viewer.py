# viewer.py
"""
FruitProj: viewer module

Goal:
    Display the chosen fruit image using Pillow (PIL).

Pseudocode:
    FUNCTION show_image(filename):
        TRY:
            OPEN image using Image.open(filename)
            CALL img.show()
        EXCEPT FileNotFoundError:
            PRINT error about missing image file
"""

from PIL import Image


def show_image(filename):
    try:
        img = Image.open(filename)
        img.show()
    except FileNotFoundError as ff:
        print(ff)


if __name__ == "__main__":
   pass

