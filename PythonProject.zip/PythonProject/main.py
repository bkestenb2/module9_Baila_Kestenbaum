# main.py
"""
FruitProj: main module

Goal:
    Coordinate the whole program:

    1. Load list of image paths from docs/images.txt (image_list.load_image_list)
    2. Display menu and get user's choice (menu.grab_fruit_choice)
    3. Log the choice to docs/log.txt (logger.log_choice)
    4. Show the chosen image (viewer.show_image)

Pseudocode:
    FUNCTION main():
        CALL load_image_list() to get images list
        CALL grab_fruit_choice(images) to get index
        IF index is not None:
            SET chosen to images[index]
            CALL log_choice(chosen)
            CALL show_image(chosen)
            PRINT confirmation

    IF this file is run directly:
        CALL main()
"""

from image_list import load_image_list
from menu import grab_fruit_choice
from logger import log_choice
from viewer import show_image


def main():
    """
    Main entry point: load images, ask user, log choice, show image.
    """
    # TODO: call load_image_list() and store in a variable images
    image = load_image_list()
    index = grab_fruit_choice(image)
    if index is not None:
        chosen = image[index]
        log_choice(chosen)
        show_image(chosen)


if __name__ == "__main__":
    main()

