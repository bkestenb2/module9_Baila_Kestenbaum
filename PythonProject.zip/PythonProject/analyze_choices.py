# analyze_choices.py
import os
from logger import re_write_log
"""
FruitProj: analyze_choices module

Goal:
    Work with docs/log.txt as a file of records.

Features:
    - Load all records (each line is one filename)
    - Count how many times each fruit appears
    - Search for a specific fruit
    - Modify records (fix spelling) and rewrite the file

Pseudocode:
    FUNCTION load_choices(log_filename):
        SET choices to empty list
        SET log_path to join DOCS_DIR and log_filename
        TRY:
            OPEN log_path for reading
                FOR each line in file:
                    STRIP whitespace
                    IF not empty:
                        APPEND to choices
        EXCEPT FileNotFoundError:
            PRINT error and RETURN empty list
        RETURN choices

    FUNCTION count_fruits(choices):
        CREATE empty dict counts
        FOR each fruit in choices:
            IF fruit already in counts:
                increment counts[fruit]
            ELSE:
                set counts[fruit] = 1
        RETURN counts

    FUNCTION search_for_fruit(choices, fruit_name):
        SET count to 0
        FOR each fruit in choices:
            IF fruit == fruit_name:
                increment count
        RETURN count

    FUNCTION fix_spelling_in_log(old_name, new_name, log_filename):
        SET log_path
        TRY:
            READ all lines, modify names in memory
            REWRITE file with updated names
        EXCEPT FileNotFoundError:
            PRINT error

    FUNCTION main():
        CALL load_choices()
        IF choices empty: RETURN
        CALL count_fruits and print results
        ASK user for a filename, search and print count
        ASK if user wants to fix spelling; if yes, call fix_spelling_in_log
"""

import os

DOCS_DIR = "docs"


def load_choices(log_filename="log.txt"):
    """
       Read the choices log from docs/log.txt.
       Each line in the file is treated as one record (one choice).
       Returns a list of strings, e.g. ["imgs/apple.jpg", "imgs/lemon.jpg", ...].
       """

    pass



def count_fruits(choices):
    """
    Given a list of filenames, return a dict mapping filename -> count.
    """
    pass


def fix_spelling_in_log(fruit_lst, old_name, new_name, log_filename="log.txt"):
    """
    Replace all occurrences of old_name with new_name in docs/log.txt.
    """

    pass


def main():
    """
    Stand-alone program to analyze and modify docs/log.txt.
    """
    # TODO: call load_choices() and store in choices
    # choices = ...

    # TODO: if choices is empty, return early
    # if not choices:
    #     return

    # TODO: call count_fruits(choices) and print each fruit/count pair
    # counts = ...
    # for fruit, ct in counts.items():
    #     print(...)

    # TODO: ask user for a filename to search for, call search_for_fruit, print result

    # TODO: ask user if they want to fix spelling (y/n)
    # if answer is "y":
    #     TODO: ask for old_name and new_name
    #     TODO: call fix_spelling_in_log(old_name, new_name)
    # TODO: call main()

    pass


if __name__ == "__main__":
    main()

