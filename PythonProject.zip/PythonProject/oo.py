import os

from image_list import DOCS_DIR

#print(os.path.join("folder", "file.txt"))
#print(os.path.abspath("docs/images.txt"))
#print(os.getcwd())

DOCS_DIR = "docs"
PATH = ""

def write_fun():
    global PATH
    PATH = os.path.join(DOCS_DIR, "hello.txt")
    with open(PATH, "w") as f:
        f.write("hello world \n")
        f.write("welcome to writing in python")

def append_fun():
    global PATH
    PATH = os.path.join(DOCS_DIR, "hello.txt")
    print(PATH)
    with open(PATH, "r") as f:
        f.write("I am appending \n")
        f.write("This comes after we write")

def read_fun():
    # PATH = os.path.join(DOCS_DIR, "hello.txt")
    print(PATH)
    with open(PATH, "r") as f:
        for lines in f:
            print(lines.strip().replace("\n", ""))



def main():
    write_fun()
    read_fun()
    append_fun()
    read_fun()


if __name__ == "__main__":
    main()